#ifndef  _APP_DELEGATE_H_
#define  _APP_DELEGATE_H_

#include "JCSCos2x_Lib_src\JCSCos2x.h"

/**
@brief    The cocos2d Application.

Private inheritance here hides part of interface from Director.
*/
class  AppDelegate : private cocos2d::Application
{
private:
	char* m_windowTitle = "JCSCos2x Demo";
	int32 m_windowWidth = 1600;
	int32 m_windowHeight = 900;
	const float32 m_fps = 60.0f;

    const float32 m_fadeInTime = 2.0f;      // sec

	JCSCos2x::JCSCos2x_Layer* m_pLayer = nullptr;
	cocos2d::Scene* m_pScene = nullptr;

public:
    AppDelegate();
    virtual ~AppDelegate();

    virtual void initGLContextAttrs();

    /**
    @brief    Implement Director and Scene init code here.
    @return true    Initialize success, app continue.
    @return false   Initialize failed, app terminate.
    */
    virtual bool applicationDidFinishLaunching();

    /**
    @brief  Called when the application moves to the background
    @param  the pointer of the application
    */
    virtual void applicationDidEnterBackground();

    /**
    @brief  Called when the application reenters the foreground
    @param  the pointer of the application
    */
    virtual void applicationWillEnterForeground();

	/*
	Called when the application is about to terminate.
	See also applicationDidEnterBackground:.
	*/
	virtual void applicationWillTerminate();
};

#endif // _APP_DELEGATE_H_

