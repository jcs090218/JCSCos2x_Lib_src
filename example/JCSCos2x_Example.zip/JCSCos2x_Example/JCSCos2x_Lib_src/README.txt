========================================================================
$File: README.txt $
$Creator: Jen-Chieh Shen <jcs090218@gmail.com> $
$Date: 2016-12-05 $
$Revision: 1.0.7 $
$Version Control Page:  $
$Notice: See LICENSE.txt for modification and distribution information 
                  Copyright (c) 2016 by Shen, Jen-Chieh $
========================================================================


    Simply include these file in the main project then it should work.
    
    - What does this library do?
        This library provide the the interface of understanding cocos2d-x framework, 
        so developer can easily use the cocos2d-x framework instead of reading those out 
        dated documenetation on other website. is a small library and simple wrapper, i 
        do not think ppl will spent that much of time reading the source code.
