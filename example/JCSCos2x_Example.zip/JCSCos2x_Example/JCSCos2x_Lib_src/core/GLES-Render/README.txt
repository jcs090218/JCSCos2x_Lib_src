These files are what I have found useful if you use Box2d for
your physic engine. Note that Box2d have already been include
by Cocos2d-x itself.