/**
 * $File: BackgroundLayer.cpp $
 * $Date: 2016-11-26 20:01:43 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */

#include "BackgroundLayer.h"

Scene* BackgroundLayer::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();

    // 'layer' is an autorelease object
    auto layer = BackgroundLayer::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

bool BackgroundLayer::jcscos_init(void)
{
    // get window instance info.
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    this->SetLayerFriction(-0.5f);


    float back_4_height = -46.667999f;

    auto sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/IDvampireEU_town - no name/back_4.png",
        0, back_4_height);

    // mid hill.
    {
        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_4.png",
            416.72f, back_4_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_4.png",
            -416.72f, back_4_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_4.png",
            -416.72f * 2, back_4_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_4.png",
            -416.72f * 3, back_4_height);
    }

    return true;
}

void BackgroundLayer::jcscos_update(float32 deltaTime)
{

}

void BackgroundLayer::jcscos_exit(void)
{
    // safe delete / release here...
}

void BackgroundLayer::menuCloseCallback(Ref* pSender)
{
    JCSCos2x::JCSCos2x_Layer::menuCloseCallback(pSender);

}
