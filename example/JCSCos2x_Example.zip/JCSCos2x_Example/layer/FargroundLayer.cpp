/**
 * $File: FargroundLayer.cpp $
 * $Date: 2016-12-10 23:03:22 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */

#include "FargroundLayer.h"

Scene* FargroundLayer::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();

    // 'layer' is an autorelease object
    auto layer = FargroundLayer::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

FargroundLayer::~FargroundLayer()
{
    
}

bool FargroundLayer::jcscos_init(void)
{
    this->SetLayerFriction(-0.7f);

    float blue_height = 10;
    float back_2_height = 16.616590f;

    auto sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/IDvampireEU_town - no name/back_0.png",
        0, blue_height);

    // sky blue base layer.
    {
        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_0.png",
            811, blue_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_0.png",
            -811, blue_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_0.png",
            -811 * 2, blue_height);
    }

    float far_mountain_height = -9.019607f;

    // Far mountain
    {
        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            0, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            99.73f, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            99.73f * 2, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            99.73f * 3, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            99.73f * 4, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 1, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 2, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 3, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 4, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 5, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 6, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 7, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 8, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 9, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 10, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 11, far_mountain_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_1.png",
            -99.73f * 12, far_mountain_height);

        // always add the last sprite to control.
        //SetSpriteControl(sprite);
    }

    // Mountain.
    {
        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_2.png",
            0, back_2_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_2.png",
            -658.04f, back_2_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_2.png",
            658.04f, back_2_height);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_2.png",
            -658.04f * 2, back_2_height);
    }

    // always add the last sprite to control.
    //SetSpriteControl(animationSprite);

    return true;
}

void FargroundLayer::jcscos_start(void)
{

}

void FargroundLayer::jcscos_update(float32 deltaTime)
{

}

void FargroundLayer::jcscos_exit(void)
{
    // safe delete / release here...
}

void FargroundLayer::menuCloseCallback(Ref* pSender)
{
    JCSCos2x::JCSCos2x_Layer::menuCloseCallback(pSender);

}
