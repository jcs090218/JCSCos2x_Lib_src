#ifndef __FARGROUNDLAYER_H__
/**
 * $File: FargroundLayer.h $
 * $Date: 2016-12-10 23:03:24 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */
#define __FARGROUNDLAYER_H__

#include "JCSCos2x_Lib_src\JCSCos2x.h"


class FargroundLayer
    : public JCSCos2x::JCSCos2x_Layer
{
private:
    Vec2 m_velocity = Vec2::ZERO;
    float m_walkSpeed = 50;
    float m_jumpSpeed = 10;


public:
    static cocos2d::Scene* createScene();
    ~FargroundLayer();

    virtual bool jcscos_init(void) override;
    virtual void jcscos_start(void) override;
    virtual void jcscos_update(float32 deltaTime) override;
    virtual void jcscos_exit(void) override;

    // smart pointer handle for cocos2dx framework
    CREATE_FUNC(FargroundLayer);

    // a selector callback
    virtual void menuCloseCallback(cocos2d::Ref* pSender);

    /** setter **/

    /** getter **/

};


#endif // __FARGROUNDLAYER_H__
