/**
 * $File: ForegroundLayer.cpp $
 * $Date: 2016-12-10 18:35:09 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */

#include "ForegroundLayer.h"

Scene* ForegroundLayer::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();

    // 'layer' is an autorelease object
    auto layer = ForegroundLayer::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

bool ForegroundLayer::jcscos_init(void)
{
    // get window instance info.
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    this->SetLayerFriction(0.3f);

    auto sprite = Sprite::create("Sprite/fore_ground_light.png");
    sprite->setPosition(Vec2(-100, 100));
    this->addChild(sprite, 0);

    sprite = Sprite::create("Sprite/fore_ground_light.png");
    sprite->setPosition(Vec2(-1100, 100));
    this->addChild(sprite, 0);

    float bottom_bushes_height = -125.214806f;

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        0, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        280.992584f, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        280.992584f * 2, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        280.992584f * 3, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        280.992584f * 4, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f * 2, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f * 3, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f * 4, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f * 5, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f * 6, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f * 7, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f * 8, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f * 9, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f * 10, bottom_bushes_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        -280.992584f * 11, bottom_bushes_height);


    return true;
}

void ForegroundLayer::jcscos_update(float32 deltaTime)
{

}

void ForegroundLayer::jcscos_exit(void)
{
    // safe delete / release here...
}

void ForegroundLayer::menuCloseCallback(Ref* pSender)
{
    JCSCos2x::JCSCos2x_Layer::menuCloseCallback(pSender);

}
