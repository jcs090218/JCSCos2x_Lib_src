#ifndef __FOREGROUNDLAYER_H__
/**
 * $File: ForegroundLayer.h $
 * $Date: 2016-12-10 18:35:07 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */
#define __FOREGROUNDLAYER_H__

#include "JCSCos2x_Lib_src\JCSCos2x.h"

class ForegroundLayer
    : public JCSCos2x::JCSCos2x_Layer
{
private:
    cocos2d::Sprite* m_pHelloWorldSprite = nullptr;
    cocos2d::Sprite* m_pOtherSprite = nullptr;

    Vec2 m_velocity = Vec2::ZERO;
    float m_walkSpeed = 25;
    float m_jumpSpeed = 10;

    // gravity constant
    const float m_gravity = 9.81f;

public:
    static cocos2d::Scene* createScene();

    virtual bool jcscos_init(void) override;
    virtual void jcscos_update(float32 deltaTime) override;
    virtual void jcscos_exit(void) override;

    // smart pointer handle for cocos2dx framework
    CREATE_FUNC(ForegroundLayer);

    // a selector callback
    virtual void menuCloseCallback(cocos2d::Ref* pSender);

    /** setter **/

    /** getter **/

};

#endif // __FOREGROUNDLAYER_H__
