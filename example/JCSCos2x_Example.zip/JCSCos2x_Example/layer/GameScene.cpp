/**
 * $File: GameScene.cpp $
 * $Date: 2016-11-23 23:34:23 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */

#include "GameScene.h"

Scene* GameScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();

    // 'layer' is an autorelease object
    auto layer = GameScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

bool GameScene::jcscos_init(void)
{
    // get window instance info.
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    // add the created object to the layer here...

    // play the background music.
    GetSoundPlayer()->PlayBGM("../../Resources/Sound/bgm/menu.mp3", true);

    // STUDY(jenchieh): not able to set the volume?? platform specific?
    GetSoundPlayer()->GetSimpleAduioEngine()->setBackgroundMusicVolume(0.5f);

    m_pSprite = Sprite::create("Sprite/CrazyCat/summon.fly_1.png");
    m_pSprite->setPosition(
        Vec2(visibleSize.width / 2 + origin.x,
            visibleSize.height / 2 + origin.y));

    // add the created object to the layer here...
    this->addChild(m_pSprite, 0);

    return true;
}

void GameScene::jcscos_update(float32 deltaTime)
{
    if (GetJCSInput()->GetKey(JCSCos2x_KeyCode::KEY_UP_ARROW))
        m_velocity.y = m_walkSpeed;
    else if (GetJCSInput()->GetKey(JCSCos2x_KeyCode::KEY_DOWN_ARROW))
        m_velocity.y = -m_walkSpeed;
    else
        m_velocity.y = 0;

    Vec2 newPos = m_pSprite->getPosition();

    // apply gravity
    m_velocity.y -= m_gravity * deltaTime;

    newPos.x += m_velocity.x * deltaTime;
    newPos.y += m_velocity.y * deltaTime;

    m_pSprite->setPosition(newPos);

    if (GetJCSInput()->GetKeyDown(JCSCos2x_KeyCode::KEY_UP_ARROW))
        GetSoundPlayer()->PlayOneShot("../../Resources/Sound/sfx/jump.mp3");
}

void GameScene::jcscos_exit(void)
{
    // safe delete / release here...
}

void GameScene::menuCloseCallback(Ref* pSender)
{
    JCSCos2x::JCSCos2x_Layer::menuCloseCallback(pSender);

}
