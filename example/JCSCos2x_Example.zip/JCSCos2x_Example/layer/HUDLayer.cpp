/**
 * $File: HUDLayer.cpp $
 * $Date: 2016-11-26 15:42:44 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */

#include "HUDLayer.h"


Scene* HUDLayer::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();

    // 'layer' is an autorelease object
    auto layer = HUDLayer::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

bool HUDLayer::jcscos_init(void)
{
    // get window instance info.
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    m_pHelloWorldSprite = Sprite::create("HelloWorld.png");
    m_pHelloWorldSprite->setPosition(
        Point(
            visibleSize.width / 2 + 200,
            visibleSize.height / 2 - 60
        ));

    this->addChild(m_pHelloWorldSprite, 0);

    // this is the HUD layer not the game layer.
    this->SetIsGameLayer(false);

    return true;
}

void HUDLayer::jcscos_update(float32 deltaTime)
{

}

void HUDLayer::jcscos_exit(void)
{
    // safe delete / release here...
}

void HUDLayer::menuCloseCallback(Ref* pSender)
{
    JCSCos2x::JCSCos2x_Layer::menuCloseCallback(pSender);

}
