/**
 * $File: MenuScene.cpp $
 * $Date: 2016-11-23 22:58:20 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */

#include "MenuScene.h"
#include "CreditScene.h"
#include "GameScene.h"
#include "TestScene.h"

#include "SimpleAudioEngine.h"

Scene* MenuScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();

    // 'layer' is an autorelease object
    auto layer = MenuScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

MenuScene::~MenuScene()
{

}

bool MenuScene::jcscos_init(void)
{
    // get window instance info.
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    // add the created object to the layer here...

    // play the background music.
    GetSoundPlayer()->PlayBGM("../../Resources/Sound/bgm/menu.mp3", true, 1.0f);
    runAction(JCSCos2x_MusicFade::create(1.5f, 1.0f));


    m_pLogoSprite = Sprite::create("HelloWorld.png");
    m_pLogoSprite->setPosition(
        Point(
            visibleSize.width / 2,
            visibleSize.height / 2 + 200
        ));

    // absolute move, delta move use "MoveBy"
    auto logoAction = MoveTo::create(3, 
        Point(
            visibleSize.width / 2, 
            visibleSize.height / 2 + 50));

    // add action.
    m_pLogoSprite->runAction(EaseElasticInOut::create(logoAction));
    

    // create menu item here.
    auto menu_play = MenuItemFont::create("Play", CC_CALLBACK_1(MenuScene::Play, this));
    auto menu_credit = MenuItemFont::create("Credit", CC_CALLBACK_1(MenuScene::Credit, this));

    // set the font item position here.
    menu_play->setPosition(Point(0, (visibleSize.height / 2) - 180));
    menu_credit->setPosition(Point(0, (visibleSize.height / 2) - 220));

    // create menu item.
    auto* menu = Menu::create(
        menu_play,
        menu_credit, 
        NULL);

    // set menu position
    menu->setPosition(Point(0, 0));

    // add menu to scene child
    this->addChild(menu);
    this->addChild(m_pLogoSprite, 0);

    return true;
}

void MenuScene::jcscos_update(float32 deltaTime)
{
    if (GetJCSInput()->GetKeyDown(JCSCos2x_KeyCode::KEY_UP_ARROW))
    {
        //runAction(JCSCos2x_MusicFade::create(1.5f, 0.0f));
        m_pLogoSprite->setScaleX(1);
    }
    else if (GetJCSInput()->GetKeyDown(JCSCos2x_KeyCode::KEY_DOWN_ARROW))
    {
        //runAction(JCSCos2x_MusicFade::create(1.5f, 1.0f));
    }
}

void MenuScene::jcscos_exit(void)
{
    // safe delete / release here...
}

void MenuScene::menuCloseCallback(Ref* pSender)
{
    JCSCos2x::JCSCos2x_Layer::menuCloseCallback(pSender);
}

void MenuScene::Credit(cocos2d::Ref* pSender)
{
    GetSoundPlayer()->PlayOneShot("../../Resources/Sound/sfx/mouseClick.mp3");

    auto scene = CreditScene::createScene();

    Director::getInstance()->replaceScene(TransitionSlideInT::create(0.5f, scene));
}

void MenuScene::Play(cocos2d::Ref* pSender)
{
    GetSoundPlayer()->PlayOneShot("../../Resources/Sound/sfx/mouseClick.mp3");

    // create the scene
    auto scene = TestScene::createScene();

    JCSCos2x::SwitchScene<TestScene>(2, Color3B(255, 255, 255));
}
