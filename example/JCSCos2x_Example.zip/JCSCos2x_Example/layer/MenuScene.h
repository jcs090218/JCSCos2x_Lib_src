#ifndef __MENUSCENE_H__
/**
 * $File: MenuScene.h $
 * $Date: 2016-11-23 22:58:16 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */
#define __MENUSCENE_H__


#include "JCSCos2x_Lib_src\JCSCos2x.h"


class MenuScene
    : public JCSCos2x::JCSCos2x_Layer
{
private:
    cocos2d::Sprite* m_pLogoSprite = nullptr;

public:
    static cocos2d::Scene* createScene();
    ~MenuScene();

    virtual void jcscos_update(float32 deltaTime) override;
    virtual bool jcscos_init(void) override;
    virtual void jcscos_exit(void) override;

    // smart pointer handle for cocos2dx framework
    CREATE_FUNC(MenuScene);

    // a selector callback
    virtual void menuCloseCallback(cocos2d::Ref* pSender);

private:
    /**
    @breif Play font.
    */
    void Play(cocos2d::Ref* pSender);
    /**
    @breif Credit font.
    */
    void Credit(cocos2d::Ref* pSender);
    
};

#endif // __MENUSCENE_H__
