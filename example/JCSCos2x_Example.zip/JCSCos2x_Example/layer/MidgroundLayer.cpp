/**
 * $File: MidgroundLayer.cpp $
 * $Date: 2016-12-05 20:40:46 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */

#include "MidgroundLayer.h"


Scene* MidgroundLayer::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();

    // 'layer' is an autorelease object
    auto layer = MidgroundLayer::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

MidgroundLayer::~MidgroundLayer()
{
    SafeDeleteObject(m_pGameObject);
}

bool MidgroundLayer::jcscos_init(void)
{
    // set the friction for our layer.
    this->SetLayerFriction(-0.4f);

    float base_cloud_height = 40;

    {
        m_cloudSprite[0] = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_6.png",
            1000, base_cloud_height + 10);

        m_cloudSprite[1] = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_6.png",
            0, base_cloud_height);

        m_cloudSprite[2] = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_6.png",
            -1000, base_cloud_height - 10);
    }

    float back_5_height = -63.27f;

    auto sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/IDvampireEU_town - no name/back_5.png",
        0, back_5_height);

    {
        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/IDvampireEU_town - no name/back_5.png",
            -483.46f, back_5_height);
        sprite->setFlippedX(true);
    }

    
    auto animationSprite = JCSCos2x::CreateAnimationInLayer(
        this,
        -218.48f, 58.46f,
        "Sprite/ID11thFestival - no name/",
        "ani.4_",
        6,
        ".png",
        0.5f);

    animationSprite = JCSCos2x::CreateAnimationInLayer(
        this,
        -440.116f, 8.61f,
        "Sprite/ID11thFestival - no name/",
        "ani.5_",
        6,
        ".png",
        0.5f);

    animationSprite = JCSCos2x::CreateAnimationInLayer(
        this,
        -1440.116f, 8.61f,
        "Sprite/ID11thFestival - no name/",
        "ani.5_",
        6,
        ".png",
        0.5f);

    animationSprite = JCSCos2x::CreateAnimationInLayer(
        this,
        12.59f, -20.62f,
        "Sprite/IDvampireEU_town - no name/",
        "ani.0_",
        11,
        ".png",
        0.5f);

    animationSprite = JCSCos2x::CreateAnimationInLayer(
        this,
        -475.66f, -20.62f,
        "Sprite/IDvampireEU_town - no name/",
        "ani.0_",
        11,
        ".png",
        0.5f);

    animationSprite->setFlippedX(true);


    // always add the last sprite to control.
    //SetSpriteControl(animationSprite);

    return true;
}

void MidgroundLayer::jcscos_start(void)
{
    
}

void MidgroundLayer::jcscos_update(float32 deltaTime)
{
    for (int index = 0;
        index < CLOUD_COUNT;
        ++index)
    {
        Sprite* cloudSprite = m_cloudSprite[index];

        Vec2 newPos = cloudSprite->getPosition();

        newPos.x += m_cloudSpeed * deltaTime;

        if (m_cloudSpeed > 0)
        {
            if (newPos.x > 1000)
                newPos.x = -3000;
        }
        else
        {
            if (newPos.x < -3000)
                newPos.x = 1000;
        }

        cloudSprite->setPosition(newPos);
    }
}

void MidgroundLayer::jcscos_exit(void)
{
    // safe delete / release here...
}

void MidgroundLayer::menuCloseCallback(Ref* pSender)
{
    JCSCos2x::JCSCos2x_Layer::menuCloseCallback(pSender);

}
