#ifndef __MIDGROUNDLAYER_H__
/**
 * $File: MidgroundLayer.h $
 * $Date: 2016-12-05 20:40:38 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */
#define __MIDGROUNDLAYER_H__


#include "JCSCos2x_Lib_src\JCSCos2x.h"

#define CLOUD_COUNT 3

class MidgroundLayer
    : public JCSCos2x::JCSCos2x_Layer
{
private:
    Vec2 m_velocity = Vec2::ZERO;
    float m_walkSpeed = 50;
    float m_jumpSpeed = 10;

    cocos2d::Sprite* m_pOtherSprite = nullptr;

    // gravity constant
    const float m_gravity = 9.81f;

    JCSCos2x::JCSCos2x_GameObject* m_pGameObject = nullptr;

    cocos2d::Sprite* m_cloudSprite[CLOUD_COUNT];
    const float m_cloudSpeed = 20;

public:
    static cocos2d::Scene* createScene();
    ~MidgroundLayer();

    virtual bool jcscos_init(void) override;
    virtual void jcscos_start(void) override;
    virtual void jcscos_update(float32 deltaTime) override;
    virtual void jcscos_exit(void) override;

    // smart pointer handle for cocos2dx framework
    CREATE_FUNC(MidgroundLayer);

    // a selector callback
    virtual void menuCloseCallback(cocos2d::Ref* pSender);

    /** setter **/

    /** getter **/

};

#endif // __MIDGROUNDLAYER_H__
