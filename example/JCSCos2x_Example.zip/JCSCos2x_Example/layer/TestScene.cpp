/**
 * $File: TestScene.cpp $
 * $Date: 2016-11-17 22:13:02 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */

#include "TestScene.h"
#include "HUDLayer.h"
#include "BackgroundLayer.h"
#include "MidgroundLayer.h"
#include "ForegroundLayer.h"
#include "FargroundLayer.h"

#include "MenuScene.h"


Scene* TestScene::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

    FargroundLayer* fargroundLayer = FargroundLayer::create();
    scene->addChild(fargroundLayer);

    // NOTE(jenchieh): multiple layer added here.
    // SOURCE(jenchieh): http://discuss.cocos2d-x.org/t/issue-adding-multiple-layers-to-one-scene/6952/2
    BackgroundLayer* backgroundLayer = BackgroundLayer::create();
    // 越後面的layer要先addChild.
    scene->addChild(backgroundLayer);

    MidgroundLayer* midgroundLayer = MidgroundLayer::create();
    scene->addChild(midgroundLayer);

    // Game Layer
    auto layer = TestScene::create();
    scene->addChild(layer);

    // fore ground
    ForegroundLayer* foreground = ForegroundLayer::create();
    scene->addChild(foreground);

    // HUD
    HUDLayer* hudLayer = HUDLayer::create();
    scene->addChild(hudLayer);

	// return the scene
	return scene;
}

TestScene::~TestScene()
{
    SafeDeleteObject(m_pPlayer);
    SafeDeletePtrArrayObject(m_pAI, AI_COUNT);
}

bool TestScene::jcscos_init(void)
{
    // get window instance info.
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

	/*Label* helloWorldText = Label::createWithSystemFont("Hi there", "Arial", 96);
	helloWorldText->setAnchorPoint(Vec2(0, 0));
    this->addChild(helloWorldText, 1);*/

	// play the background music.
    GetSoundPlayer()->PlayBGM("../../Resources/Sound/bgm/menu.mp3", true);

    // 
    m_pPlayer = new JCSCos2x::JCSCos2x_GameObject();
    m_pPlayer->Initialize();
    //m_pPlayer->GetJCSCos2xAnimator()->SetFilePath("Sprite/CrazyCat/");
    m_pPlayer->SetFilePath("Sprite/CrazyCat/");
    
    //m_pPlayer->GetJCSCos2xAnimator()->DoAnimationWithFile("summon.move_", 4, 0.1f);

    JCSCos2x::JCSCos2x_Layer::s_followFriction = 0.4f;


    this->CreateScene();

    // add the created object to the layer here...
    this->addChild(m_pPlayer->GetSprite(), 0);

    InitAIs();

	return true;
}

void TestScene::InitAIs(void)
{
    for (int index = 0;
        index < AI_COUNT;
        ++index)
    {
        m_pAI[index] = new JCSCos2x::JCSCos2x_GameObject();

        JCSCos2x::JCSCos2x_GameObject* tempAI = m_pAI[index];

        tempAI->Initialize();
        tempAI->SetFilePath("Sprite/CrazyCat/");

        // apply random position.
        float spawnRange = 100.0f;

        tempAI->SetPosition(
            cocos2d::random(-spawnRange, spawnRange),
            cocos2d::random(-spawnRange, spawnRange));

        this->addChild(tempAI->GetSprite(), 0);
    }
}

void TestScene::jcscos_start(void)
{
	// set the target to current sprite.
	this->SetCameraTargetTarget(m_pPlayer->GetSprite());

	this->SetCameraMaxX(300);
    this->SetCameraMinX(-2000);
    this->SetCameraMinY(0);

    m_pPlayer->DoAnimation("summon.move_", 4, 0.1f);

    // player should always walk left.
    m_velocity.x = -m_walkSpeed;

    StartAIs();
}

void TestScene::jcscos_update(float32 deltaTime)
{
    this->UpdatePlayer(deltaTime);
    this->UpdateAIs(deltaTime);

    DoGameRule(deltaTime);

    // set back to menu.
    if (GetJCSInput()->GetKeyDown(JCSCos2x_KeyCode::KEY_B))
        BackToMenu();
}

void TestScene::jcscos_exit(void)
{
	// safe delete / release here...
}

void TestScene::menuCloseCallback(Ref* pSender)
{
	JCSCos2x::JCSCos2x_Layer::menuCloseCallback(pSender);

}

void TestScene::UpdatePlayer(const float32 deltaTime)
{

#ifdef _DEBUG
    FreeControlPlayer(deltaTime);
    Test(deltaTime);
#endif

    // do jumping?
    if (GetJCSInput()->GetKey(JCSCos2x_KeyCode::KEY_SPACE) && !m_jumping)
    {
        m_velocity.y = m_jumpForce;
        GetSoundPlayer()->PlayOneShot("../../Resources/Sound/sfx/jump.mp3");
        m_jumping = true;
    }

    Vec2 newPos = m_pPlayer->GetSprite()->getPosition();

    // only when is not controlling the player.
#ifdef _DEBUG
    //if (!m_controlPlayer)
#endif
    {
        // apply gravity
        m_velocity.y -= m_gravity * deltaTime * m_gravityProduct;
    }

    newPos.x += m_velocity.x * deltaTime;
    newPos.y += m_velocity.y * deltaTime;

    // check is on the ground.
    if (newPos.y <= m_groundHeight)
    {
        newPos.y = m_groundHeight;
        m_velocity.y = 0;
        m_jumping = false;
    }

    // apply new position.
    m_pPlayer->GetSprite()->setPosition(newPos);

    if (GetJCSInput()->GetKeyDown(JCSCos2x_KeyCode::KEY_R))
    {
        // reset player position to starting position.
        ResetPlayerPosition();
    }

    if (m_jumping)
    {
        m_pPlayer->DoAnimation("summon.fly_", 4, 0.2f);
    }
    else
    {
        if (m_velocity.x == 0)
        {
            m_pPlayer->DoAnimation("summon.attack1_", 22, 0.1f);
        }
        else
        {
            m_pPlayer->DoAnimation("summon.move_", 4, 0.1f);
        }
    }
}

void TestScene::StartAIs(void)
{
    for (int32 index = 0;
        index < AI_COUNT;
        ++index)
    {
        JCSCos2x::JCSCos2x_GameObject* tempAI = m_pAI[index];

        // apply random velocity.
        m_velocityAI[index].x = -cocos2d::RandomHelper::random_real(
            m_walkSpeed - m_speedOffset,
            m_walkSpeed + m_speedOffset);

        tempAI->DoAnimation("summon.move_", 4, 0.1f);
    }
}

void TestScene::UpdateAIs(const float32 deltaTime)
{
    for (int32 index = 0;
        index < AI_COUNT;
        ++index)
    {
        Vec2 newPos = m_pAI[index]->GetSprite()->getPosition();

        // apply gravity
        m_velocityAI[index].y -= m_gravity * deltaTime * m_gravityProduct;

        float jump = random(0, 100);

        if (jump > m_jumpPossibility)
        {
            // do jumping?
            if (jump && !m_jumpingAI[index])
            {
                m_velocityAI[index].y = m_jumpForce;
                m_jumpingAI[index] = true;
            }
        }

        newPos.x += m_velocityAI[index].x * deltaTime;
        newPos.y += m_velocityAI[index].y * deltaTime;

        // check is on the ground.
        if (newPos.y <= m_groundHeight)
        {
            newPos.y = m_groundHeight;
            m_velocityAI[index].y = 0;
            m_jumpingAI[index] = false;
        }

        // apply new position.
        m_pAI[index]->GetSprite()->setPosition(newPos);

        // update animation.
        if (m_jumpingAI[index])
        {
            m_pAI[index]->DoAnimation("summon.fly_", 4, 0.2f);
        }
        else
        {
            m_pAI[index]->DoAnimation("summon.move_", 4, 0.1f);
        }
    }
}

#ifdef _DEBUG
void TestScene::FreeControlPlayer(const float32 deltaTime)
{
    if (GetJCSInput()->GetKeyDown(JCSCos2x_KeyCode::KEY_O))
    {
        // toggle player.
        m_controlPlayer = !m_controlPlayer;
    }

    // check if freely control player?
    if (!m_controlPlayer)
        return;

    static float addSpeed = 100;

    if (GetJCSInput()->GetKey(JCSCos2x_KeyCode::KEY_LEFT_ARROW))
    {
        m_velocity.x = -m_walkSpeed - addSpeed;

        m_pPlayer->DoAnimation("summon.move_", 4, 0.1f);
        m_pPlayer->GetSprite()->setFlippedX(false);
    }
    else if (GetJCSInput()->GetKey(JCSCos2x_KeyCode::KEY_RIGHT_ARROW))
    {
        m_velocity.x = m_walkSpeed + addSpeed;

        m_pPlayer->DoAnimation("summon.move_", 4, 0.1f);
        m_pPlayer->GetSprite()->setFlippedX(true);
    }
    else
        m_velocity.x = 0;

    //if (GetJCSInput()->GetKey(JCSCos2x_KeyCode::KEY_UP_ARROW))
    //{
    //    m_velocity.y = m_walkSpeed + addSpeed;
    //}
    //else if (GetJCSInput()->GetKey(JCSCos2x_KeyCode::KEY_DOWN_ARROW))
    //{
    //    m_velocity.y = -m_walkSpeed - addSpeed;
    //}
    //else
    //    m_velocity.y = 0;
}

void TestScene::Test(const float32 deltaTime)
{
    if (GetJCSInput()->GetKey(JCSCos2x_KeyCode::KEY_H))
    {
        m_velocity.x = -300;
    }
}
#endif

void TestScene::ResetPlayerPosition(void)
{
    // check if player nullptr
    if (!m_pPlayer)
        return;

    m_pPlayer->SetPosition(0, 0);

    m_jumping = true;
}

void TestScene::CreateScene(void)
{
    float ground_part_01_height = -60.819f;
    float ground_part_02_height = -72.4f;

    std::string ground_part_01_filePath = "Sprite/ground_part_01.png";
    std::string ground_part_02_filePath = "Sprite/ground_part_02.png";

    float mid_bushes = -88.271996f;

    auto sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/ID11thFestival - no name/back_17.png",
        0, mid_bushes);

    // bushes
    {
        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/ID11thFestival - no name/back_17.png",
            280.992584f, mid_bushes);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/ID11thFestival - no name/back_17.png",
            280.992584f * 2, mid_bushes);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/ID11thFestival - no name/back_17.png",
            -280.992584f, mid_bushes);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/ID11thFestival - no name/back_17.png",
            -280.992584f * 2, mid_bushes);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/ID11thFestival - no name/back_17.png",
            -280.992584f * 3, mid_bushes);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/ID11thFestival - no name/back_17.png",
            -280.992584f * 4, mid_bushes);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/ID11thFestival - no name/back_17.png",
            -280.992584f * 5, mid_bushes);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/ID11thFestival - no name/back_17.png",
            -280.992584f * 6, mid_bushes);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/ID11thFestival - no name/back_17.png",
            -280.992584f * 7, mid_bushes);

        sprite = JCSCos2x::CreateSpriteInLayer(
            this,
            "Sprite/ID11thFestival - no name/back_17.png",
            -280.992584f * 8, mid_bushes);

        // always add the last sprite to control.
        //SetSpriteControl(sprite);
    }

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_01_filePath,
        0, ground_part_01_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_02_filePath,
        203.09f, ground_part_02_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_01_filePath,
        420.477f, ground_part_01_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_02_filePath,
        623.41f, ground_part_02_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_02_filePath,
        -217.41f, ground_part_02_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_01_filePath,
        -420.477f, ground_part_01_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_02_filePath,
        -420.477f - 217.41f, ground_part_02_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_01_filePath,
        -420.477f * 2, ground_part_01_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_02_filePath,
        (-420.477f * 2) - 217.41f, ground_part_02_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_01_filePath,
        -420.477f * 3, ground_part_01_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_02_filePath,
        (-420.477f * 3) - 217.41f, ground_part_02_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_01_filePath,
        -420.477f * 4, ground_part_01_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_02_filePath,
        (-420.477f * 4) - 217.41f, ground_part_02_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_01_filePath,
        -420.477f * 5, ground_part_01_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_02_filePath,
        (-420.477f * 5) - 217.41f, ground_part_02_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_01_filePath,
        -420.477f * 6, ground_part_01_height);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        ground_part_02_filePath,
        (-420.477f * 6) - 217.41f, ground_part_02_height);

    SetSpriteControl(sprite);

    sprite = JCSCos2x::CreateSpriteInLayer(
        this,
        "Sprite/gil.png",
        72.07f, -75.144f);


    auto animationSprite = JCSCos2x::CreateAnimationInLayer(
        this,
        -1973.17f, -88.31f,
        "Sprite/ID2010009 - Lenario/",
        "say_",
        14,
        ".png",
        0.2f);
    animationSprite->setFlippedX(true);

    // always add the last sprite to control.
    //SetSpriteControl(animationSprite);
}

void TestScene::DoGameRule(const float32 deltaTime)
{
    // after certain distance, back to menu scene.
    if (m_pPlayer->GetSprite()->getPosition().x < m_goalDistance)
    {
        BackToMenu();
    }

}

void TestScene::BackToMenu(void)
{
    // check loading?
    if (m_backToMenu)
        return;

    JCSCos2x::SwitchSceneWithBGM<MenuScene>(
        2,
        "../../Resources/Sound/bgm/menu.mp3",
        Color3B(255, 255, 255));

    m_backToMenu = true;
}
