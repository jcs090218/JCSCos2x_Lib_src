#ifndef __TESTSCENE_H__
/**
 * $File: TestScene.h $
 * $Date: 2016-11-17 22:12:57 $
 * $Revision: $
 * $Creator: Jen-Chieh Shen $
 * $Notice: See LICENSE.txt for modification and distribution information
 *                   Copyright (c) 2016 by Shen, Jen-Chieh $
 */
#define __TESTSCENE_H__

#include "JCSCos2x_Lib_src\JCSCos2x.h"

#define AI_COUNT 1

/**
Test scene to test the scene feature here...
*/
class TestScene
	: public JCSCos2x::JCSCos2x_Layer
{
private:

	Vec2 m_velocity = Vec2::ZERO;
	float m_walkSpeed = 100;
	float m_jumpForce = 180;

    cocos2d::Sprite* m_pOtherSprite = nullptr;

	// gravity constant
	const float m_gravity = 9.81f;
    const float m_gravityProduct = 15;

    const float m_groundHeight = -85;

    // if reach this distance load back to menu scene.
    const float m_goalDistance = -2300;

    // trigger to check if is already loading the scene.
    bool m_backToMenu = false;

    //-- Player --//
    JCSCos2x::JCSCos2x_GameObject* m_pPlayer= nullptr;
    bool m_jumping = false;

#ifdef _DEBUG
    // trigger control the player freely?
    bool m_controlPlayer = false;
#endif

    //-- AI --//
    JCSCos2x::JCSCos2x_GameObject* m_pAI[AI_COUNT];
    bool m_jumpingAI[AI_COUNT];
    float32 m_walkSpeedAI[AI_COUNT];
    cocos2d::Vec2 m_velocityAI[AI_COUNT];
    float m_speedOffset = 10;
    float m_jumpPossibility = 10;

public:
	static cocos2d::Scene* createScene();
    ~TestScene();

	virtual void jcscos_update(float32 deltaTime) override;
	virtual void jcscos_start(void) override;
	virtual bool jcscos_init(void) override;
	virtual void jcscos_exit(void) override;

    /* update the player logic. */
    void UpdatePlayer(const float32 deltaTime);

    /* Create the whole scene */
    void CreateScene(void);

	// smart pointer handle for cocos2dx framework
	CREATE_FUNC(TestScene);

	// a selector callback
	virtual void menuCloseCallback(cocos2d::Ref* pSender);

private:

    /* Reset player's position back to where the player original start */
    void ResetPlayerPosition();

    /* Design the game rule here. */
    void DoGameRule(const float32 deltaTime);

    /** Back to menu screen */
    void BackToMenu(void);

    /* Initialize the AIs */
    void InitAIs(void);

    /* Start game logic for AIs */
    void StartAIs(void);

    /* Update game logic for AIs */
    void UpdateAIs(const float32 deltaTime);

#ifdef _DEBUG
    /* Do control of the player freely. */
    void FreeControlPlayer(const float32 deltaTime);

    /* test the game */
    void Test(const float32 deltaTime);
#endif
};

#endif // __TESTSCENE_H__
